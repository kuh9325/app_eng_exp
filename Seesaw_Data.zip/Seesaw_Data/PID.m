%load data
load('PID.mat');
load('PD.mat');
load('P.mat');
%initialization time on zero
time1 = time1 - time1(1);
time2 = time2 - time2(1);
time3 = time3 - time3(1);

%time-angle w/ cmd Diagram [PID]
figure (1)
subplot(2,3,1);
plot(time1,angle1,'b','LineWidth',1);
hold on
plot(time1,command1,'r','LineWidth',1);
set(gcf,'color','w')
title('time-angle w/ cmd Diagram [PID]','fontsize',12)
xlabel('Time(sec)','fontsize',12)
ylabel('Angle(deg)','fontsize',12)

%time-angle w/ cmd Diagram [PD]
subplot(2,3,2);
plot(time2,angle2,'b','LineWidth',1);
hold on
plot(time2,command2,'r','LineWidth',1);
set(gcf,'color','w')
title('time-angle w/ cmd Diagram [PD]','fontsize',12)
xlabel('Time(sec)','fontsize',12)
ylabel('Angle(deg)','fontsize',12)

%time-angle w/ cmd Diagram [P]
subplot(2,3,3);
plot(time3,angle3,'b','LineWidth',1);
hold on
plot(time3,command3,'r','LineWidth',1);
set(gcf,'color','w')
legend('angle','command')
title('time-angle w/ cmd Diagram [P]','fontsize',12)
xlabel('Time(sec)','fontsize',12)
ylabel('Angle(deg)','fontsize',12)

%time-angular velocity w/ cmd Diagram [PID]
subplot(2,3,4);
plot(time1,av1,'c','LineWidth',1);
hold on
plot(time1,command1,'m','LineWidth',1);
set(gcf,'color','w')
title('time-angular velocity w/ cmd Diagram [PID]','fontsize',12)
xlabel('Time(sec)','fontsize',12)
ylabel('Angular Velocity(RPM)','fontsize',12)

%time-angular velocity w/ cmd Diagram [PD]
subplot(2,3,5);
plot(time2,av2,'c','LineWidth',1);
hold on
plot(time2,command2,'m','LineWidth',1);
set(gcf,'color','w')
title('time-angular velocity w/ cmd Diagram [PD]','fontsize',12)
xlabel('Time(sec)','fontsize',12)
ylabel('Angular Velocity(RPM)','fontsize',12)

%time-angular velocity w/ cmd Diagram [PID]
subplot(2,3,6);
plot(time3,av3,'c','LineWidth',1);
hold on
plot(time3,command3,'m','LineWidth',1);
set(gcf,'color','w')
legend('angular velocity','command')
title('time-angular velocity w/ cmd Diagram [P]','fontsize',12)
xlabel('Time(sec)','fontsize',12)
ylabel('Angular Velocity(RPM)','fontsize',12)

%calculating error
err1 = abs(command1 - angle1);
err2 = abs(command2 - angle2);
err3 = abs(command3 - angle3);
%apply PID gain into manipulated variable
for i=1:1924
    MV1(i) = P1(i)*err1(i) + I1(i)*err1(i)*1924 + D1(1)*err1(i)/1924;
end
for i=1:1589
    MV2(i) = P1(i)*err1(i) + I1(i)*err1(i)*1589 + D1(1)*err1(i)/1589;
end
for i=1:528
    MV3(i) = P1(i)*err1(i) + I1(i)*err1(i)*528 + D1(1)*err1(i)/528;
end
%time-PID w/ cmd Diagram
figure (2)
plot(time1,MV1,'b','LineWidth',1);
hold on
plot(time2,MV2,'g','LineWidth',1);
plot(time3,MV3,'c','LineWidth',1);
plot(time1,command1,'r','LineWidth',1);
set(gcf,'color','w')
legend('PID','PD','P','command')
title('time-PID w/ cmd Diagram','fontsize',12)
xlabel('Time(sec)','fontsize',12)
ylabel('Gain','fontsize',12)
